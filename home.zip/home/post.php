<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="en-au" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Login Page username&nbsp;&nbsp; Password</title>
<style type="text/css">
.auto-style1 {
	text-align: center;
}
</style>
</head>

<body>

<form method="post" action="second.php">
	<div class="auto-style1">
		<br />
		Login Page<br />
		username&nbsp; <input name="Text1" type="text" /><br />
		Password <input name="Password1" type="password" /><br />
		<input name="Submit1" type="submit" value="submit" /></div>
</form>

</body>

</html>
